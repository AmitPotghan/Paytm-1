const JWT_SECRET = "Amit@1234";
module.exports = JWT_SECRET;